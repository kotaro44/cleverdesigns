window.onload = function(){
	$(".img-wrapper").click(function(){
		$(this).addClass("full-screen");
		$(".blackscreen").addClass("visible")
	});

	$(".blackscreen").click(function(){
		$(this).removeClass("visible");
		$(".full-screen").removeClass("full-screen");
	})
}